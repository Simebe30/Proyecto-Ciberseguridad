namespace ProyectoFinalSimuladorSeguridadInformatica
{
    // ─────────────────────────────────────────────
    // PALETA DE COLORES — TEMA OSCURO MINIMALISTA
    // Centraliza todos los colores de la interfaz
    // ─────────────────────────────────────────────
    public static class ColorPaleta
    {
        // Fondo principal — negro profundo
        public static readonly Color Fondo = Color.FromArgb(8, 8, 10);

        // Fondo de paneles y tarjetas
        public static readonly Color FondoPanel = Color.FromArgb(13, 14, 18);

        // Fondo de campos de entrada
        public static readonly Color FondoInput = Color.FromArgb(18, 19, 24);

        // Borde sutil entre elementos
        public static readonly Color Borde = Color.FromArgb(32, 34, 42);

        // Borde activo / tab seleccionado
        public static readonly Color BordeActivo = Color.FromArgb(55, 58, 72);

        // Acento — azul frío apagado
        public static readonly Color Acento = Color.FromArgb(88, 130, 200);

        // Verde — resultado fuerte / seguro
        public static readonly Color Verde = Color.FromArgb(70, 160, 110);

        // Amarillo — resultado medio / advertencia
        public static readonly Color Amarillo = Color.FromArgb(180, 150, 70);

        // Rojo — resultado débil / peligro
        public static readonly Color Rojo = Color.FromArgb(170, 70, 70);

        // Texto principal
        public static readonly Color TextoPrincipal = Color.FromArgb(190, 195, 210);

        // Texto secundario / etiquetas
        public static readonly Color TextoSecundario = Color.FromArgb(80, 86, 105);

        // Texto del terminal
        public static readonly Color TerminalTexto = Color.FromArgb(100, 155, 115);
    }
}

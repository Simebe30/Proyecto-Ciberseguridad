namespace ProyectoFinalSimuladorSeguridadInformatica
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        // ─── Layout principal ───
        private Panel panelHeader;
        private Label lblTituloApp;
        private Label lblSubtituloApp;
        private TabControl tabPrincipal;
        private TabPage tabContrasenas;
        private TabPage tabEscaner;

        // ─── Módulo contraseñas ───
        private Panel panelContraGenerador;
        private Label lblTituloGenerador;
        private Label lblLongitud;
        private NumericUpDown numLongitud;
        private Button btnGenerar;

        private Panel panelContraAnalizador;
        private Label lblTituloAnalizador;
        private Label lblPasswordLabel;
        private TextBox txtPassword;
        private CheckBox chkMostrarContra;
        private Button btnCopiar;
        private Button btnAnalizar;

        private Panel panelFortaleza;
        private Label lblFortalezaLabel;
        private ProgressBar progressFortaleza;
        private Label lblNivelFortaleza;
        private Label lblResultadoContra;

        // ─── Módulo escáner ───
        private Panel panelEscanerInfo;
        private Label lblTituloEscaner;
        private Label lblDescEscaner;
        private Button btnSeleccionarArchivo;
        private Label lblArchivoLabel;
        private Label lblArchivoSeleccionado;
        private Label lblRutaLabel;
        private Label lblRutaCompleta;
        private Button btnEscanear;
        private Panel panelResultadoEscaner;
        private Label lblResultadoLabel;
        private Label lblEstadoEscaner;

        // ─── Terminal ───
        private Panel panelTerminal;
        private Label lblTerminalTitulo;
        private RichTextBox rtbTerminal;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();

            // ─── Instanciación ───
            panelHeader            = new Panel();
            lblTituloApp           = new Label();
            lblSubtituloApp        = new Label();
            tabPrincipal           = new TabControl();
            tabContrasenas         = new TabPage();
            tabEscaner             = new TabPage();
            panelContraGenerador   = new Panel();
            lblTituloGenerador     = new Label();
            lblLongitud            = new Label();
            numLongitud            = new NumericUpDown();
            btnGenerar             = new Button();
            panelContraAnalizador  = new Panel();
            lblTituloAnalizador    = new Label();
            lblPasswordLabel       = new Label();
            txtPassword            = new TextBox();
            chkMostrarContra       = new CheckBox();
            btnCopiar              = new Button();
            btnAnalizar            = new Button();
            panelFortaleza         = new Panel();
            lblFortalezaLabel      = new Label();
            progressFortaleza      = new ProgressBar();
            lblNivelFortaleza      = new Label();
            lblResultadoContra     = new Label();
            panelEscanerInfo       = new Panel();
            lblTituloEscaner       = new Label();
            lblDescEscaner         = new Label();
            btnSeleccionarArchivo  = new Button();
            lblArchivoLabel        = new Label();
            lblArchivoSeleccionado = new Label();
            lblRutaLabel           = new Label();
            lblRutaCompleta        = new Label();
            btnEscanear            = new Button();
            panelResultadoEscaner  = new Panel();
            lblResultadoLabel      = new Label();
            lblEstadoEscaner       = new Label();
            panelTerminal          = new Panel();
            lblTerminalTitulo      = new Label();
            rtbTerminal            = new RichTextBox();

            SuspendLayout();

            // ═══════════════════════════════════════════
            // FORMULARIO PRINCIPAL
            // ═══════════════════════════════════════════
            this.Text            = "Simulador de Seguridad Informatica";
            this.Size            = new Size(1080, 700);
            this.MinimumSize     = new Size(980, 660);
            this.BackColor       = ColorPaleta.Fondo;
            this.ForeColor       = ColorPaleta.TextoPrincipal;
            this.Font            = new Font("Consolas", 9F);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.Load           += Form1_Load;

            // ═══════════════════════════════════════════
            // HEADER
            // ═══════════════════════════════════════════
            panelHeader.Dock      = DockStyle.Top;
            panelHeader.Height    = 62;
            panelHeader.BackColor = ColorPaleta.FondoPanel;
            panelHeader.Paint    += (s, e) =>
            {
                using var pen = new Pen(ColorPaleta.Borde, 1);
                e.Graphics.DrawLine(pen, 0, panelHeader.Height - 1,
                                    panelHeader.Width, panelHeader.Height - 1);
            };

            lblTituloApp.Text      = "SIMULADOR DE SEGURIDAD INFORMATICA";
            lblTituloApp.Font      = new Font("Consolas", 13F, FontStyle.Bold);
            lblTituloApp.ForeColor = ColorPaleta.TextoPrincipal;
            lblTituloApp.Location  = new Point(22, 12);
            lblTituloApp.AutoSize  = true;

            lblSubtituloApp.Text      = "Generador / Analizador de Contrasenas   |   Escaner de Archivos";
            lblSubtituloApp.Font      = new Font("Consolas", 8.5F);
            lblSubtituloApp.ForeColor = ColorPaleta.TextoSecundario;
            lblSubtituloApp.Location  = new Point(24, 36);
            lblSubtituloApp.AutoSize  = true;

            panelHeader.Controls.AddRange(new Control[] { lblTituloApp, lblSubtituloApp });

            // ═══════════════════════════════════════════
            // TAB CONTROL
            // ═══════════════════════════════════════════
            tabPrincipal.Location  = new Point(10, 72);
            tabPrincipal.Size      = new Size(668, 585);
            tabPrincipal.Anchor    = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Bottom;
            tabPrincipal.BackColor = ColorPaleta.FondoPanel;
            tabPrincipal.DrawMode  = TabDrawMode.OwnerDrawFixed;
            tabPrincipal.ItemSize  = new Size(190, 32);
            tabPrincipal.SizeMode  = TabSizeMode.Fixed;
            tabPrincipal.DrawItem += TabPrincipal_DrawItem;

            tabContrasenas.Text       = "CONTRASENAS";
            tabContrasenas.BackColor  = ColorPaleta.FondoPanel;

            tabEscaner.Text       = "ESCANER";
            tabEscaner.BackColor  = ColorPaleta.FondoPanel;

            tabPrincipal.Controls.Add(tabContrasenas);
            tabPrincipal.Controls.Add(tabEscaner);

            // ═══════════════════════════════════════════
            // PANEL GENERADOR
            // ═══════════════════════════════════════════
            panelContraGenerador.Location  = new Point(10, 10);
            panelContraGenerador.Size      = new Size(634, 96);
            panelContraGenerador.BackColor = ColorPaleta.FondoInput;
            EstilarPanel(panelContraGenerador);

            lblTituloGenerador.Text      = "GENERADOR";
            lblTituloGenerador.Font      = new Font("Consolas", 9F, FontStyle.Bold);
            lblTituloGenerador.ForeColor = ColorPaleta.Acento;
            lblTituloGenerador.Location  = new Point(16, 12);
            lblTituloGenerador.AutoSize  = true;

            lblLongitud.Text      = "Longitud  (8 - 64)";
            lblLongitud.Font      = new Font("Consolas", 8.5F);
            lblLongitud.ForeColor = ColorPaleta.TextoSecundario;
            lblLongitud.Location  = new Point(16, 40);
            lblLongitud.AutoSize  = true;

            numLongitud.Location  = new Point(162, 37);
            numLongitud.Size      = new Size(64, 24);
            numLongitud.Minimum   = 8;
            numLongitud.Maximum   = 64;
            numLongitud.Value     = 12;
            numLongitud.BackColor = ColorPaleta.Fondo;
            numLongitud.ForeColor = ColorPaleta.TextoPrincipal;
            numLongitud.Font      = new Font("Consolas", 10F);

            EstilarBoton(btnGenerar, ColorPaleta.Acento);
            btnGenerar.Text     = "GENERAR";
            btnGenerar.Location = new Point(244, 34);
            btnGenerar.Size     = new Size(110, 30);
            btnGenerar.Click   += btnGenerar_Click;

            panelContraGenerador.Controls.AddRange(new Control[] {
                lblTituloGenerador, lblLongitud, numLongitud, btnGenerar
            });

            // ═══════════════════════════════════════════
            // PANEL ANALIZADOR
            // ═══════════════════════════════════════════
            panelContraAnalizador.Location  = new Point(10, 116);
            panelContraAnalizador.Size      = new Size(634, 118);
            panelContraAnalizador.BackColor = ColorPaleta.FondoInput;
            EstilarPanel(panelContraAnalizador);

            lblTituloAnalizador.Text      = "ANALIZADOR";
            lblTituloAnalizador.Font      = new Font("Consolas", 9F, FontStyle.Bold);
            lblTituloAnalizador.ForeColor = ColorPaleta.Acento;
            lblTituloAnalizador.Location  = new Point(16, 12);
            lblTituloAnalizador.AutoSize  = true;

            lblPasswordLabel.Text      = "Contrasena";
            lblPasswordLabel.Font      = new Font("Consolas", 8.5F);
            lblPasswordLabel.ForeColor = ColorPaleta.TextoSecundario;
            lblPasswordLabel.Location  = new Point(16, 40);
            lblPasswordLabel.AutoSize  = true;

            txtPassword.Location              = new Point(16, 58);
            txtPassword.Size                  = new Size(400, 26);
            txtPassword.BackColor             = ColorPaleta.Fondo;
            txtPassword.ForeColor             = ColorPaleta.TextoPrincipal;
            txtPassword.Font                  = new Font("Consolas", 10.5F);
            txtPassword.BorderStyle           = BorderStyle.FixedSingle;
            txtPassword.UseSystemPasswordChar = true;
            txtPassword.TextChanged          += txtPassword_TextChanged;

            chkMostrarContra.Text           = "Mostrar";
            chkMostrarContra.Location       = new Point(426, 60);
            chkMostrarContra.ForeColor      = ColorPaleta.TextoSecundario;
            chkMostrarContra.BackColor      = ColorPaleta.FondoInput;
            chkMostrarContra.Font           = new Font("Consolas", 8F);
            chkMostrarContra.AutoSize       = true;
            chkMostrarContra.CheckedChanged += chkMostrarContra_CheckedChanged;

            EstilarBotonSecundario(btnCopiar);
            btnCopiar.Text     = "Copiar";
            btnCopiar.Location = new Point(500, 56);
            btnCopiar.Size     = new Size(72, 28);
            btnCopiar.Click   += btnCopiar_Click;

            EstilarBoton(btnAnalizar, ColorPaleta.Acento);
            btnAnalizar.Text     = "ANALIZAR";
            btnAnalizar.Location = new Point(580, 56);
            btnAnalizar.Size     = new Size(42, 28);
            btnAnalizar.Click   += btnAnalizar_Click;

            panelContraAnalizador.Controls.AddRange(new Control[] {
                lblTituloAnalizador, lblPasswordLabel, txtPassword,
                chkMostrarContra, btnCopiar, btnAnalizar
            });

            // ═══════════════════════════════════════════
            // PANEL FORTALEZA
            // ═══════════════════════════════════════════
            panelFortaleza.Location  = new Point(10, 244);
            panelFortaleza.Size      = new Size(634, 118);
            panelFortaleza.BackColor = ColorPaleta.FondoInput;
            EstilarPanel(panelFortaleza);

            lblFortalezaLabel.Text      = "FORTALEZA";
            lblFortalezaLabel.Font      = new Font("Consolas", 8.5F);
            lblFortalezaLabel.ForeColor = ColorPaleta.TextoSecundario;
            lblFortalezaLabel.Location  = new Point(16, 12);
            lblFortalezaLabel.AutoSize  = true;

            progressFortaleza.Location = new Point(16, 32);
            progressFortaleza.Size     = new Size(504, 14);
            progressFortaleza.Minimum  = 0;
            progressFortaleza.Maximum  = 100;
            progressFortaleza.Value    = 0;
            progressFortaleza.Style    = ProgressBarStyle.Continuous;

            lblNivelFortaleza.Text      = "---";
            lblNivelFortaleza.Font      = new Font("Consolas", 12F, FontStyle.Bold);
            lblNivelFortaleza.ForeColor = ColorPaleta.TextoSecundario;
            lblNivelFortaleza.Location  = new Point(532, 26);
            lblNivelFortaleza.AutoSize  = true;

            lblResultadoContra.Text      = "Introduce o genera una contrasena";
            lblResultadoContra.Font      = new Font("Consolas", 8.5F);
            lblResultadoContra.ForeColor = ColorPaleta.TextoSecundario;
            lblResultadoContra.Location  = new Point(16, 58);
            lblResultadoContra.Size      = new Size(600, 50);
            lblResultadoContra.AutoSize  = false;

            panelFortaleza.Controls.AddRange(new Control[] {
                lblFortalezaLabel, progressFortaleza, lblNivelFortaleza, lblResultadoContra
            });

            tabContrasenas.Controls.AddRange(new Control[] {
                panelContraGenerador, panelContraAnalizador, panelFortaleza
            });

            // ═══════════════════════════════════════════
            // PANEL ESCANER
            // ═══════════════════════════════════════════
            panelEscanerInfo.Location  = new Point(10, 10);
            panelEscanerInfo.Size      = new Size(634, 330);
            panelEscanerInfo.BackColor = ColorPaleta.FondoInput;
            EstilarPanel(panelEscanerInfo);

            lblTituloEscaner.Text      = "ESCANER DE ARCHIVOS";
            lblTituloEscaner.Font      = new Font("Consolas", 9F, FontStyle.Bold);
            lblTituloEscaner.ForeColor = ColorPaleta.Acento;
            lblTituloEscaner.Location  = new Point(16, 12);
            lblTituloEscaner.AutoSize  = true;

            lblDescEscaner.Text      = "Analiza un archivo segun extension, nombre, ruta y tamano.";
            lblDescEscaner.Font      = new Font("Consolas", 8.5F);
            lblDescEscaner.ForeColor = ColorPaleta.TextoSecundario;
            lblDescEscaner.Location  = new Point(16, 34);
            lblDescEscaner.Size      = new Size(600, 18);

            EstilarBoton(btnSeleccionarArchivo, ColorPaleta.Acento);
            btnSeleccionarArchivo.Text     = "SELECCIONAR ARCHIVO";
            btnSeleccionarArchivo.Location = new Point(16, 66);
            btnSeleccionarArchivo.Size     = new Size(200, 30);
            btnSeleccionarArchivo.Click   += btnSeleccionarArchivo_Click;

            lblArchivoLabel.Text      = "Archivo :";
            lblArchivoLabel.Font      = new Font("Consolas", 8.5F);
            lblArchivoLabel.ForeColor = ColorPaleta.TextoSecundario;
            lblArchivoLabel.Location  = new Point(16, 114);
            lblArchivoLabel.AutoSize  = true;

            lblArchivoSeleccionado.Text        = "ninguno";
            lblArchivoSeleccionado.Font        = new Font("Consolas", 9F, FontStyle.Bold);
            lblArchivoSeleccionado.ForeColor   = ColorPaleta.TextoPrincipal;
            lblArchivoSeleccionado.Location    = new Point(90, 114);
            lblArchivoSeleccionado.Size        = new Size(530, 18);
            lblArchivoSeleccionado.AutoEllipsis = true;

            lblRutaLabel.Text      = "Ruta    :";
            lblRutaLabel.Font      = new Font("Consolas", 8.5F);
            lblRutaLabel.ForeColor = ColorPaleta.TextoSecundario;
            lblRutaLabel.Location  = new Point(16, 136);
            lblRutaLabel.AutoSize  = true;

            lblRutaCompleta.Text        = "";
            lblRutaCompleta.Font        = new Font("Consolas", 8F);
            lblRutaCompleta.ForeColor   = ColorPaleta.TextoSecundario;
            lblRutaCompleta.Location    = new Point(90, 136);
            lblRutaCompleta.Size        = new Size(530, 18);
            lblRutaCompleta.AutoEllipsis = true;

            EstilarBoton(btnEscanear, ColorPaleta.Verde);
            btnEscanear.Text     = "ESCANEAR";
            btnEscanear.Location = new Point(16, 168);
            btnEscanear.Size     = new Size(130, 30);
            btnEscanear.Enabled  = false;
            btnEscanear.Click   += btnEscanear_Click;

            // Criterios de evaluacion mostrados como lista
            string[] criterios = {
                "Extension del archivo    (.exe  .bat  .dll  .ps1 ...)",
                "Nombre del archivo       (virus  hack  crack  keygen ...)",
                "Ubicacion en el sistema  (System32  Temp  SysWOW64 ...)",
                "Tamano del archivo       (anomalias grandes o muy pequeñas)"
            };

            int cy = 218;
            foreach (var c in criterios)
            {
                var lbl = new Label
                {
                    Text      = "  " + c,
                    Font      = new Font("Consolas", 8F),
                    ForeColor = ColorPaleta.TextoSecundario,
                    Location  = new Point(16, cy),
                    AutoSize  = true
                };
                panelEscanerInfo.Controls.Add(lbl);
                cy += 18;
            }

            // Separador visual antes de los criterios
            var lblCriteriosTitulo = new Label
            {
                Text      = "Criterios de evaluacion",
                Font      = new Font("Consolas", 8.5F, FontStyle.Bold),
                ForeColor = ColorPaleta.TextoSecundario,
                Location  = new Point(16, 200),
                AutoSize  = true
            };
            panelEscanerInfo.Controls.Add(lblCriteriosTitulo);

            panelEscanerInfo.Controls.AddRange(new Control[] {
                lblTituloEscaner, lblDescEscaner,
                btnSeleccionarArchivo,
                lblArchivoLabel, lblArchivoSeleccionado,
                lblRutaLabel, lblRutaCompleta,
                btnEscanear
            });

            // ─── Panel resultado escaner ───
            panelResultadoEscaner.Location  = new Point(10, 350);
            panelResultadoEscaner.Size      = new Size(634, 90);
            panelResultadoEscaner.BackColor = ColorPaleta.FondoInput;
            EstilarPanel(panelResultadoEscaner);

            lblResultadoLabel.Text      = "RESULTADO";
            lblResultadoLabel.Font      = new Font("Consolas", 8.5F);
            lblResultadoLabel.ForeColor = ColorPaleta.TextoSecundario;
            lblResultadoLabel.Location  = new Point(16, 12);
            lblResultadoLabel.AutoSize  = true;

            lblEstadoEscaner.Text      = "Esperando archivo...";
            lblEstadoEscaner.Font      = new Font("Consolas", 13F, FontStyle.Bold);
            lblEstadoEscaner.ForeColor = ColorPaleta.TextoSecundario;
            lblEstadoEscaner.Location  = new Point(16, 34);
            lblEstadoEscaner.Size      = new Size(600, 44);

            panelResultadoEscaner.Controls.AddRange(new Control[] {
                lblResultadoLabel, lblEstadoEscaner
            });

            tabEscaner.Controls.AddRange(new Control[] {
                panelEscanerInfo, panelResultadoEscaner
            });

            // ═══════════════════════════════════════════
            // TERMINAL (panel derecho, sin boton CLR)
            // ═══════════════════════════════════════════
            panelTerminal.Location  = new Point(688, 72);
            panelTerminal.Size      = new Size(370, 585);
            panelTerminal.Anchor    = AnchorStyles.Top | AnchorStyles.Right | AnchorStyles.Bottom;
            panelTerminal.BackColor = ColorPaleta.FondoPanel;
            EstilarPanel(panelTerminal);

            lblTerminalTitulo.Text      = "TERMINAL";
            lblTerminalTitulo.Font      = new Font("Consolas", 8.5F, FontStyle.Bold);
            lblTerminalTitulo.ForeColor = ColorPaleta.TextoSecundario;
            lblTerminalTitulo.Location  = new Point(12, 12);
            lblTerminalTitulo.AutoSize  = true;

            // Línea separadora bajo el título del terminal
            var sepTerminal = new Panel
            {
                Location  = new Point(0, 32),
                Size      = new Size(370, 1),
                BackColor = ColorPaleta.Borde
            };

            rtbTerminal.Location    = new Point(0, 33);
            rtbTerminal.Size        = new Size(370, 548);
            rtbTerminal.Anchor      = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Bottom | AnchorStyles.Right;
            rtbTerminal.BackColor   = ColorPaleta.Fondo;
            rtbTerminal.ForeColor   = ColorPaleta.TerminalTexto;
            rtbTerminal.Font        = new Font("Consolas", 8.5F);
            rtbTerminal.ReadOnly    = true;
            rtbTerminal.BorderStyle = BorderStyle.None;
            rtbTerminal.ScrollBars  = RichTextBoxScrollBars.Vertical;
            rtbTerminal.Padding     = new Padding(8, 6, 0, 0);

            panelTerminal.Controls.AddRange(new Control[] {
                lblTerminalTitulo, sepTerminal, rtbTerminal
            });

            // ═══════════════════════════════════════════
            // AGREGAR TODO AL FORMULARIO
            // ═══════════════════════════════════════════
            this.Controls.AddRange(new Control[] {
                panelHeader, tabPrincipal, panelTerminal
            });

            ResumeLayout(false);
        }

        // ─────────────────────────────────────────────
        // HELPERS DE ESTILO
        // ─────────────────────────────────────────────

        // Dibuja un borde de 1px alrededor del panel
        private void EstilarPanel(Panel panel)
        {
            panel.Paint += (s, e) =>
            {
                using var pen = new Pen(ColorPaleta.Borde, 1);
                e.Graphics.DrawRectangle(pen, 0, 0, panel.Width - 1, panel.Height - 1);
            };
        }

        // Botón primario con color de acento
        private void EstilarBoton(Button btn, Color colorBase)
        {
            btn.BackColor                        = Color.FromArgb(18, colorBase.R, colorBase.G, colorBase.B);
            btn.ForeColor                        = colorBase;
            btn.FlatStyle                        = FlatStyle.Flat;
            btn.FlatAppearance.BorderColor       = Color.FromArgb(80, colorBase.R, colorBase.G, colorBase.B);
            btn.FlatAppearance.BorderSize        = 1;
            btn.FlatAppearance.MouseOverBackColor = Color.FromArgb(36, colorBase.R, colorBase.G, colorBase.B);
            btn.Font                             = new Font("Consolas", 8.5F, FontStyle.Bold);
            btn.Cursor                           = Cursors.Hand;
        }

        // Botón secundario (sin color de acento)
        private void EstilarBotonSecundario(Button btn)
        {
            btn.BackColor                        = ColorPaleta.FondoInput;
            btn.ForeColor                        = ColorPaleta.TextoSecundario;
            btn.FlatStyle                        = FlatStyle.Flat;
            btn.FlatAppearance.BorderColor       = ColorPaleta.Borde;
            btn.FlatAppearance.BorderSize        = 1;
            btn.FlatAppearance.MouseOverBackColor = ColorPaleta.Borde;
            btn.Font                             = new Font("Consolas", 8.5F);
            btn.Cursor                           = Cursors.Hand;
        }

        // ─────────────────────────────────────────────
        // DIBUJADO DEL TAB CONTROL
        // Renderiza las pestañas con el tema oscuro
        // ─────────────────────────────────────────────
        private void TabPrincipal_DrawItem(object? sender, DrawItemEventArgs e)
        {
            bool sel = (e.Index == tabPrincipal.SelectedIndex);

            Color bgColor = sel
                ? Color.FromArgb(18, ColorPaleta.Acento.R, ColorPaleta.Acento.G, ColorPaleta.Acento.B)
                : ColorPaleta.Fondo;

            Color fgColor = sel ? ColorPaleta.Acento : ColorPaleta.TextoSecundario;

            using var bgBrush = new SolidBrush(bgColor);
            e.Graphics.FillRectangle(bgBrush, e.Bounds);

            // Línea inferior en la pestaña activa
            if (sel)
            {
                using var pen = new Pen(ColorPaleta.Acento, 1);
                e.Graphics.DrawLine(pen,
                    e.Bounds.Left, e.Bounds.Bottom - 1,
                    e.Bounds.Right, e.Bounds.Bottom - 1);
            }

            string texto = tabPrincipal.TabPages[e.Index].Text;
            using var fgBrush = new SolidBrush(fgColor);
            var sf = new StringFormat
            {
                Alignment     = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };
            e.Graphics.DrawString(texto,
                new Font("Consolas", 9F, FontStyle.Bold),
                fgBrush, e.Bounds, sf);
        }
    }
}

using System.Text.Json;

namespace ProyectoFinalSimuladorSeguridadInformatica
{
    public partial class Form1 : Form
    {
        public Escaner Escaner { get; set; }
        private ReglasSeguridad reglas;
        private AnalizadorContra analizador;
        private GeneradorContra generador;

        public Form1()
        {
            InitializeComponent();
            Escaner = new Escaner();
            InicializarBackend();
        }

        // ─────────────────────────────────────────────
        // INICIALIZACIÓN DEL BACKEND
        // Carga el diccionario JSON y crea las instancias
        // ─────────────────────────────────────────────
        private void InicializarBackend()
        {
            try
            {
                string jsonString = File.ReadAllText("contrasTipicas.json");
                List<string> diccionario = JsonSerializer.Deserialize<List<string>>(jsonString) ?? new List<string>();
                reglas = new ReglasSeguridad(diccionario);
                analizador = new AnalizadorContra(reglas);
                generador = new GeneradorContra();
            }
            catch (FileNotFoundException)
            {
                reglas = new ReglasSeguridad(new List<string>());
                analizador = new AnalizadorContra(reglas);
                generador = new GeneradorContra();
                AppendTerminal("AVISO  diccionario no encontrado, analisis sin diccionario");
            }
            catch (Exception ex)
            {
                reglas = new ReglasSeguridad(new List<string>());
                analizador = new AnalizadorContra(reglas);
                generador = new GeneradorContra();
                AppendTerminal($"ERROR  {ex.Message}");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            AnimarBienvenida();
        }

        // ─────────────────────────────────────────────
        // MÓDULO CONTRASEÑAS — GENERAR
        // Llama a GeneradorContra.Generar con la longitud indicada
        // ─────────────────────────────────────────────
        private void btnGenerar_Click(object sender, EventArgs e)
        {
            int longitud = (int)numLongitud.Value;
            string password = generador.Generar(longitud);

            if (password.StartsWith("Error"))
            {
                MostrarResultadoContra(password, TipoResultado.Error);
                return;
            }

            txtPassword.Text = password;
            AppendTerminal($"GEN    longitud={longitud}  resultado={password}");

            // Análisis automático tras generar
            string resultado = analizador.Analizar(password);
            MostrarResultadoContra(resultado, ClasificarResultado(resultado));
            ActualizarBarraFortaleza(resultado);
            AppendTerminal($"ANL    {resultado}");
        }

        // ─────────────────────────────────────────────
        // MÓDULO CONTRASEÑAS — ANALIZAR
        // Llama a AnalizadorContra.Analizar con la contraseña del campo
        // ─────────────────────────────────────────────
        private void btnAnalizar_Click(object sender, EventArgs e)
        {
            string password = txtPassword.Text;

            if (string.IsNullOrEmpty(password))
            {
                MostrarResultadoContra("Error: la contraseña no puede estar vacia", TipoResultado.Error);
                return;
            }

            string resultado = analizador.Analizar(password);
            MostrarResultadoContra(resultado, ClasificarResultado(resultado));
            ActualizarBarraFortaleza(resultado);
            AppendTerminal($"ANL    {resultado}");
        }

        // ─────────────────────────────────────────────
        // MÓDULO ESCANER — SELECCIONAR ARCHIVO
        // Abre un OpenFileDialog y llama a Escaner.AddRuta
        // ─────────────────────────────────────────────
        private void btnSeleccionarArchivo_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Seleccionar archivo para analizar",
                Filter = "Todos los archivos (*.*)|*.*"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string rutaArchivo = openFileDialog.FileName;
                lblArchivoSeleccionado.Text = Path.GetFileName(rutaArchivo);
                lblRutaCompleta.Text = rutaArchivo;
                lblRutaCompleta.ForeColor = ColorPaleta.TextoSecundario;

                Escaner.AddRuta(rutaArchivo);
                btnEscanear.Enabled = true;

                AppendTerminal($"CARGA  {rutaArchivo}");
            }
        }

        // ─────────────────────────────────────────────
        // MÓDULO ESCANER — ESCANEAR
        // Llama a Escaner.Analizar y muestra el resultado
        // ─────────────────────────────────────────────
        private void btnEscanear_Click(object sender, EventArgs e)
        {
            lblEstadoEscaner.Text = "Analizando...";
            lblEstadoEscaner.ForeColor = ColorPaleta.Acento;
            Application.DoEvents();

            string resultado = Escaner.Analizar();

            MostrarResultadoEscaner(resultado);
            AppendTerminal($"SCAN   {resultado}");
        }

        // ─────────────────────────────────────────────
        // EVENTOS AUXILIARES
        // ─────────────────────────────────────────────

        // Muestra u oculta la contraseña
        private void chkMostrarContra_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = !chkMostrarContra.Checked;
        }

        // Actualiza la barra de fortaleza mientras el usuario escribe
        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            if (txtPassword.Text.Length > 0)
            {
                string resultado = analizador.Analizar(txtPassword.Text);
                ActualizarBarraFortaleza(resultado);
            }
            else
            {
                progressFortaleza.Value = 0;
                lblNivelFortaleza.Text = "---";
                lblNivelFortaleza.ForeColor = ColorPaleta.TextoSecundario;
            }
        }

        // Copia la contraseña al portapapeles
        private void btnCopiar_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtPassword.Text))
            {
                Clipboard.SetText(txtPassword.Text);
                string original = btnCopiar.Text;
                btnCopiar.Text = "Copiado";
                Task.Delay(1500).ContinueWith(_ =>
                {
                    this.Invoke(() => btnCopiar.Text = original);
                });
                AppendTerminal("COPY   contraseña copiada al portapapeles");
            }
        }

        // ─────────────────────────────────────────────
        // HELPERS DE UI — RESULTADOS Y TERMINAL
        // ─────────────────────────────────────────────

        private enum TipoResultado { Fuerte, Media, Debil, Error, Exito }

        private TipoResultado ClasificarResultado(string resultado)
        {
            string lower = resultado.ToLower();
            if (lower.Contains("fuerte")) return TipoResultado.Fuerte;
            if (lower.Contains("media")) return TipoResultado.Media;
            return TipoResultado.Debil;
        }

        private void MostrarResultadoContra(string mensaje, TipoResultado tipo)
        {
            lblResultadoContra.Text = mensaje;
            lblResultadoContra.ForeColor = tipo switch
            {
                TipoResultado.Fuerte => ColorPaleta.Verde,
                TipoResultado.Exito  => ColorPaleta.Verde,
                TipoResultado.Media  => ColorPaleta.Amarillo,
                TipoResultado.Debil  => ColorPaleta.Rojo,
                TipoResultado.Error  => ColorPaleta.Rojo,
                _                    => ColorPaleta.TextoSecundario
            };
        }

        private void ActualizarBarraFortaleza(string resultado)
        {
            string lower = resultado.ToLower();
            if (lower.Contains("fuerte"))
            {
                progressFortaleza.Value = 100;
                lblNivelFortaleza.Text = "FUERTE";
                lblNivelFortaleza.ForeColor = ColorPaleta.Verde;
            }
            else if (lower.Contains("media"))
            {
                progressFortaleza.Value = 55;
                lblNivelFortaleza.Text = "MEDIA";
                lblNivelFortaleza.ForeColor = ColorPaleta.Amarillo;
            }
            else
            {
                progressFortaleza.Value = 20;
                lblNivelFortaleza.Text = "DEBIL";
                lblNivelFortaleza.ForeColor = ColorPaleta.Rojo;
            }
        }

        private void MostrarResultadoEscaner(string resultado)
        {
            string lower = resultado.ToLower();
            Color color;

            if (lower.Contains("muy alto"))      color = ColorPaleta.Rojo;
            else if (lower.Contains("alto"))     color = Color.FromArgb(160, 80, 60);
            else if (lower.Contains("medio"))    color = ColorPaleta.Amarillo;
            else                                  color = ColorPaleta.Verde;

            lblEstadoEscaner.Text = resultado;
            lblEstadoEscaner.ForeColor = color;
            panelResultadoEscaner.BackColor = Color.FromArgb(20, color.R, color.G, color.B);
        }

        // Escribe una línea en el terminal con timestamp
        private void AppendTerminal(string linea)
        {
            string ts = DateTime.Now.ToString("HH:mm:ss");
            rtbTerminal.SelectionColor = ColorPaleta.TextoSecundario;
            rtbTerminal.AppendText($"[{ts}]  ");
            rtbTerminal.SelectionColor = ColorPaleta.TerminalTexto;
            rtbTerminal.AppendText($"{linea}\n");
            rtbTerminal.ScrollToCaret();
        }

        // Mensajes de bienvenida al arrancar la app
        private async void AnimarBienvenida()
        {
            string[] lineas =
            {
                "SISTEMA  inicializando modulos...",
                "OK       generador de contrasenas",
                "OK       analizador de contrasenas",
                "OK       escaner de archivos",
                "LISTO    esperando entrada"
            };

            foreach (string l in lineas)
            {
                AppendTerminal(l);
                await Task.Delay(90);
            }
        }
    }
}
